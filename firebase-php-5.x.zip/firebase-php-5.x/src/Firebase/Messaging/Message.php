<?php

declare(strict_types=1);

namespace Kreait\Firebase\Messaging;

interface Message extends \JsonSerializable
{
}
